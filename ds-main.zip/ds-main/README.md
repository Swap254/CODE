# chutiye study kiya kar. 
# Lab me kya makkhi mar raha tha kya 
